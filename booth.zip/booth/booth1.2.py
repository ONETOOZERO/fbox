#!/usr/bin/python
# coding: utf-8


# To Do:
# Fehlercodes per Blinksignal?
# Drucken


import thread
from time import sleep
import RPi.GPIO as GPIO
import os
import subprocess
from time import strftime as date
import logging

baseDir = '/home/pi/photobooth/booth/'
saveDir = '/home/pi/images/'
usbDir = '/home/pi/usb-fake/'
printername = "HP" #"MFCJ625DW" #"Samsung_CLP-320_Series" #"Brother" #Samsung"
timeBetweenPics = 0.1
timeIdle = 0.1

photo_width  = 1296
photo_height = 972
photo_quality = 90
#photo_width  = 2592
#photo_height = 1944

file_prefix = 'picture_'
gBlinker = True

logging.basicConfig(level=logging.DEBUG, filename=baseDir+"logs/booth.log", filemode="a+", format="%(asctime)-15s %(levelname)-8s %(message)s")
#logging.basicConfig(level=logging.WARNING, filename=baseDir+"logs/booth.log", filemode="a+", format="%(asctime)-15s %(levelname)-8s %(message)s")
logging.info("    neuer start, neues glueck!")
logging.info("Job gestartet")

# do not show warinings
GPIO.setwarnings(False)

#GPIO.setmode(GPIO.BOARD)
GPIO.setmode(GPIO.BCM)

# Numbering by GPIO BCM
# Pin 31/32 and 15/16
LED_01 = 6
LED_02 = 12
LED_03 = 22
LED_04 = 23
LED_GO = 17 # pic taking
LED_ID = 18 # idle
# Input GPIO ports for trigger button
TRIGGER_IN = 26 # Color Picture

# setup connectors
GPIO.setup(LED_01, GPIO.OUT)
GPIO.setup(LED_02, GPIO.OUT)
GPIO.setup(LED_03, GPIO.OUT)
GPIO.setup(LED_04, GPIO.OUT)
GPIO.setup(LED_GO, GPIO.OUT)
GPIO.setup(LED_ID, GPIO.OUT)
GPIO.setup(TRIGGER_IN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Hintergrund thread um den knopf im idle zustand blinken zu lassen: 
def LED_BLINKER ( threadName, dummyValue ):
  GPIO.setup(LED_ID, GPIO.OUT)
  while True:
    if (gBlinker == True):
       #logging.info("  T2 ... blinken!")
       GPIO.output(LED_ID,GPIO.LOW)
       sleep (timeIdle)
       GPIO.output(LED_ID,GPIO.HIGH)
       sleep (timeIdle);
    else: 
       GPIO.output(LED_ID,GPIO.LOW)
       sleep (timeIdle);

# Funktion zum Einstellen der LED Status
def LED_ANZEIGE ( int ):
    if ( int == 0 ):
        logging.info(" 0  0  0  0 | 0")
        GPIO.output(LED_01,GPIO.LOW)
        GPIO.output(LED_02,GPIO.LOW)
        GPIO.output(LED_03,GPIO.LOW)
        GPIO.output(LED_04,GPIO.LOW)
        GPIO.output(LED_GO,GPIO.LOW);
    if ( int == 1 ):
        logging.info(" X  0  0  0 | 0")
        GPIO.output(LED_01,GPIO.HIGH)
        GPIO.output(LED_02,GPIO.LOW)
        GPIO.output(LED_03,GPIO.LOW)
        GPIO.output(LED_04,GPIO.LOW)
        GPIO.output(LED_GO,GPIO.LOW);
    if ( int == 2 ):
        logging.info(" 0  X  0  0 | 0")
        GPIO.output(LED_01,GPIO.LOW)
        GPIO.output(LED_02,GPIO.HIGH)
        GPIO.output(LED_03,GPIO.LOW)
        GPIO.output(LED_04,GPIO.LOW)
        GPIO.output(LED_GO,GPIO.LOW);
    if ( int == 3 ):
        logging.info(" 0  0  X  0 | 0")
        GPIO.output(LED_01,GPIO.LOW)
        GPIO.output(LED_02,GPIO.LOW)
        GPIO.output(LED_03,GPIO.HIGH)
        GPIO.output(LED_04,GPIO.LOW)
        GPIO.output(LED_GO,GPIO.LOW);
    if ( int == 4 ):
        logging.info(" 0  0  0  X | 0")
        GPIO.output(LED_01,GPIO.LOW)
        GPIO.output(LED_02,GPIO.LOW)
        GPIO.output(LED_03,GPIO.LOW)
        GPIO.output(LED_04,GPIO.HIGH)
        GPIO.output(LED_GO,GPIO.LOW);
    if ( int == 6 ):
        logging.info(" 0  0  0  0 | X")
        GPIO.output(LED_01,GPIO.LOW)
        GPIO.output(LED_02,GPIO.LOW)
        GPIO.output(LED_03,GPIO.LOW)
        GPIO.output(LED_04,GPIO.LOW)
        GPIO.output(LED_GO,GPIO.HIGH);

# to confirm action to user, the GO LED can blink
def LED_DONE (loops):
    for i in range (1, loops + 1):
        LED_ANZEIGE (6)
        sleep(timeIdle)
        LED_ANZEIGE (0)
        sleep(timeIdle);


# initialize LEDs
LED_ANZEIGE(0)

# Kick of idle thread for blinking button
try:
   thread.start_new_thread( LED_BLINKER, ("test", 1) )
except thread.error, e :
    logging.error("Error threading")
    logging.error(e)
 
# start main job
try:
    while 1:
        #############################################################
        # Wait for trigger
        #############################################################
        logging.info('Waiting for trigger')
        gBlinker = True
#        GPIO.wait_for_edge(TRIGGER_IN, GPIO.FALLING)
        gBlinker = False
        logging.info('Trigger detected ###################################################')
        #LED_ANZEIGE (1)
        sleep(0.1)               # billiger Schmidt Trigger
        for p in xrange(1,5):     # Pro Bild (pic) ein loop
            #########################################################
            # Start visual countdown
            #########################################################
            logging.info("Loop start with " + str(timeBetweenPics))
            for t in range(1,5): # countdown vor Bild anzeigen
                 LED_ANZEIGE (t)
                 sleep(timeBetweenPics)
            logging.info("Loop end")
            #########################################################
            # Take the picture to output_p.jpg
            #########################################################
            # -ex night
            #cmd = 'raspistill -ISO 400 --timeout 1 --quality ' + str(photo_quality) + ' -o ' + baseDir + 'output_' + str(p) + '.jpg -w ' + str(photo_width) + ' -h ' + str(photo_height) 
            cmd = 'gphoto2 --camera "Canon EOS 60D" --capture-image-and-download --filename "' + saveDir + 'output_' + str(p) + '.jpg" --force-overwrite'
            logging.info("Bild " + str(p) + " machen. " + cmd)
            LED_ANZEIGE(6)       # activate photo LED
            pid = subprocess.call(cmd, shell=True)
            logging.info("Bild gemacht (raspistill over)")
            if ( p < 4 ):
               LED_ANZEIGE(1)    # reset to LED 1
            else :
               LED_ANZEIGE(0)    # nach dem vierten Foto kein Strom mehr auf die 1. LED
            cmd = 'convert -bordercolor White ' + baseDir + 'output_' + str(p) + '.jpg -border 50x50 ' + baseDir + 'output_' + str(p) + '.jpg'
            logging.info(cmd)
            pid = subprocess.call(cmd, shell=True)
            logging.info("convert done " + cmd)
        logging.info('Bilder gemacht')
        #########################################################
        # Now the pictures get merged
        #########################################################
        LED_DONE (1)            # 1x blinken, postprocessing startet
        # nach allen Bildern, jetzt mergen
        savename = str(date('%Y-%m-%d_%H-%M-%S'))+'.pdf'        # Dateinamen festlegen
        logging.info("Montage and save to local file: " + baseDir + saveDir + savename)
        cmd = 'montage ' + saveDir + 'output_*.jpg -tile 2x2 -geometry 500 ' + saveDir + savename
        pid = subprocess.call(cmd, shell=True)
        logging.info("Montage done: " + cmd)
        # add timestamp to pdf file
        cmd = "convert " + saveDir + savename + " -pointsize 12 -fill grey -annotate +870+760 '" + str(date('%Y-%m-%d %H:%M')) + "' " + saveDir + savename
        pid = subprocess.call(cmd, shell=True)
        logging.info("Timestamp done: " + cmd) 
             #/mnt/pishare/output/asdf.pdf"
        #########################################################
        # Copy PDF to USB Stick
        #########################################################
        #cmd = 'cp ' + baseDir + saveDir + savename + ' ' + usbDir + savename
        #logging.info("Copy file to USB (" + cmd + ")")
        #pid = subprocess.call(cmd, shell=True)
        # tmp for now to pishare
        # cmd = 'cp ' + baseDir + saveDir + savename + ' /mnt/pishare/' + savename
        # pid = subprocess.call(cmd, shell=True)
        # logging.info("Copy done (" + cmd + ")")
        #########################################################
        # Send pdf to printer
        #########################################################
        #lp -o fit-to-page -d Samsung ./2015-08-01_21-28-11.pdf 
        #cmd = 'lp -n 2 -o fit-to-page -d ' + printername + " " + baseDir + saveDir + savename
        #logging.info("Line print (" + cmd + ")")
        #pid = subprocess.call(cmd, shell=True)
        #logging.info("Line print done, start blink")
        #LED_DONE (2)            # Blinken lassen
        logging.info('Ende Durchlauf')
        

except KeyboardInterrupt, e  : # If CTRL+C is pressed, exit cleanly:
    print "fail graceously"
    logging.exception(e)
except Exception:
    logging.exception("Exception: ")

finally:
    LED_ANZEIGE(0)              # Set all LEDs off
    GPIO.cleanup()              # cleanup all GPIO
    logging.info('Clean Exit')  

